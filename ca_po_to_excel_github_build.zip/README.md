# ca_po_to_excel — C&A PO PDF → Excel Converter (Windows EXE)

Converts C&A Purchase Order PDFs into Excel format matching the 2254607-MAIL.xls template.

## Build Windows EXE via GitHub Actions

1. Create a free GitHub account at https://github.com if you don't have one
2. Create a new **private** repository (e.g. `ca-converter`)
3. Upload `ca_po_to_excel.py` via **Add file → Upload files**
4. Create `.github/workflows/build.yml` via **Add file → Create new file**, paste the `build.yml` contents
5. Click **Actions** tab → **Build Windows EXE** → **Run workflow**
6. Wait ~2 minutes for the green ✅, then download the **ca_po_to_excel_windows** artifact

## Usage

Open Command Prompt in the same folder as the EXE:

```
ca_po_to_excel.exe  your_po_file.pdf
```

Saves `your_po_file.xlsx` in the same folder. Or specify output path:

```
ca_po_to_excel.exe  your_po_file.pdf  C:\output\result.xlsx
```

## What it extracts

- O.Style (from PDF Style Name)
- O.Ponum (PO number + country code)
- O.Ponum Log. (77337 reference number)
- Ship Date (earliest delivery date)
- Pack Type (A-PACK through N-PACK)
- D.Country / Country Code
- O.Combo (colour name)
- XS / S / M / L / XL / XXL quantities per country per pack
- Total Qty

TSS packs (small ratio packs, 12 pcs) come first, then TNSS packs (large assorted packs).
